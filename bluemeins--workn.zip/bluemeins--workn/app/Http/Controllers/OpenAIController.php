<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use App\Models\Conversation;
use Carbon\Carbon;
class OpenAIController extends Controller
{

    public function showgpt(Request $request)
    {
        $messages = Conversation::whereDate('created_at', Carbon::today())
                         ->orderBy('created_at', 'ASC') // Explicit descending order
                         ->get();
        return view('chatnew', compact('messages'));
    }

    public function getmessage(Request $request)
    {
        $messages = Conversation::whereDate('created_at', Carbon::today())
                         ->orderBy('created_at', 'ASC') // Explicit descending order
                         ->get();
        return response()->json([
            'reply' => $messages,
            'typing' => true // Used to simulate typing
        ]);
    }
    
    public function getresponse(Request $request)
    {

        $apiKey = config('services.openai.key');
        $apiUrl = config('services.openai.url');

        try {
            $userMessage = $request->input('message'); // Extract user input
            if (!$userMessage) {
                return response()->json(['error' => 'User message is required'], 400);
            }
        
            // Prepare and send the OpenAI API request
            $response = Http::withHeaders([
                'Authorization' => 'Bearer '.$apiKey ,
                'Content-Type' => 'application/json',
            ])->withOptions([
                'verify' => 'C:\wamp64\bin\php\php8.0.30\extras\ssl\cacert.pem', // Correct SSL path
            ])->post(env('OPENAI_API_URL', $apiUrl), [
                'model' => 'gpt-4o-mini',
                'messages' => [
                    ['role' => 'system', 'content' => 'You are a helpful assistant.'],
                    ['role' => 'user', 'content' => $userMessage],
                ],
            ]);
        
            // Check for failed response
            if ($response->failed()) {
                Log::error('OpenAI API Error: ' . $response->body());
                return response()->json([
                    'error' => 'Failed to connect to OpenAI',
                    'details' => $response->json('error.message') ?? $response->body(),
                ], 500);
            }
        
            // Extract the assistant's reply
            $reply = $response->json('choices.0.message.content');
            if (!$reply) {
                return response()->json([
                    'error' => 'Invalid response from OpenAI API',
                    'details' => $response->json(),
                ], 500);
            }
            $savedMessage = Conversation::create([
                'message' => $userMessage,
                'reply' => $reply,
            ]);
            // Return the reply
            return response()->json([
                'message' => $userMessage,
                'reply' => $reply,
            ]);
        
        } catch (\Exception $e) {
            // Catch and log exceptions
            Log::error('Exception in OpenAI API Request: ' . $e->getMessage());
            return response()->json([
                'error' => 'An error occurred while connecting to OpenAI',
                'details' => $e->getMessage(),
            ], 500);
        }
        

}

    
}