<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <title>ChatGPT Interface</title>
    <style>
        body {
            font-family: Arial, sans-serif;
    background-color: #f4f4f9;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: flex-start; /* Align items at the top */
    min-height: 100vh; /* Minimum height of the viewport */
    flex-direction: column; /* Ensure a top-down layout if there are multiple items */
        }
        #chat-container {
            width: 800px; /* Set the fixed width */
    max-width: 100%; /* Prevent overflow on smaller screens */
    height: 400px; /* Fixed height for the chat container */
    margin: 0 auto; /* Center the chat container */
    display: flex;
    flex-direction: column; /* Ensure a top-down layout */
    border-radius: 8px;
    background: white;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    overflow: hidden; /* Prevent overflow issues */
        }
        
        #messages {
            flex: 1;
            padding: 10px;
            overflow-y: auto;
            border-bottom: 1px solid #ddd;
            background-color:rgb(220, 208, 208);
        }
        .message {
            margin: 8px 0;
            padding: 10px;
            border-radius: 8px;
            max-width: 75%;
            word-wrap: break-word;
           
        }
        .user-message {
            align-self: flex-end;
            background-color: #007bff;
            color: white;
        }
        .assistant-message {
            align-self: flex-start;
           
        }
        #input-container {
            display: flex;
            padding: 10px;
            background:rgb(134, 134, 158);
        }
        #user-message {
            flex: 1;
            border: 1px solid #ddd;
            border-radius: 4px;
            padding: 10px;
            margin-right: 8px;
            font-size: 14px;
        }
        #send-button {
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            padding: 10px 15px;
            cursor: pointer;
        }
        #send-button:hover {
            background-color: #0056b3;
        }

        #chat-container {
            width: 1000px;
            background-color: #f9f9f9;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            margin: 50px auto;
            height: 400px;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
        }
        #chat-box {
            flex: 1;
            margin-bottom: 10px;
        }
        #input-box {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
            border-radius: 5px;
            border: 1px solid #ddd;
        }
        .message {
            margin-bottom: 15px;
        }
        .message.user {
            text-align: right;
        }
        .message.ai {
            text-align: left;
        }
    </style>
</head>
<body>
    <br><br> <br><br>
   
    <div id="chat-container"> <h3>ChatGPT</h3>
        <!-- Chat messages -->
        <div id="messages">
        <?php if(!empty($messages)): ?>
    <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p><strong><?php echo e(ucfirst($message['message'])); ?>:</strong> <?php echo e($message['reply']); ?><br><strong><?php echo e(\Carbon\Carbon::parse($message['created_at'])->format('F j, Y h:i A')); ?></strong></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    <p>No messages found.</p>
<?php endif; ?>
<div id="chat-box"></div>

        </div>
        <div id="loading" style="display:none;">
    <img src="<?php echo e('asset/img/wer.gif'); ?>" width="40px" height="30px" alt="Loading..." />
</div>
        <!-- Input box -->
        <div id="input-container">
            <input type="text" id="user-message" placeholder="Type your message..." />
            <button id="send-button">Send</button>
        </div>
    </div>

    <script>
        const messagesContainer = document.getElementById('messages');
        const userMessageInput = document.getElementById('user-message');
        const sendButton = document.getElementById('send-button');

        function appendMessage(content, role) {
            const messageDiv = document.createElement('div');
            messageDiv.classList.add('message', role === 'user' ? 'user-message' : 'assistant-message');
            messageDiv.textContent = content;
            messagesContainer.appendChild(messageDiv);
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
        }

        sendButton.addEventListener('click', async () => {
            const message = userMessageInput.value.trim();
            if (message === '') return;

            appendMessage(message, 'user');
            userMessageInput.value = '';

             // Show the loading spinner
    const loading = document.getElementById('loading');
    loading.style.display = 'block'; // Show the loader

            try {
                const response = await fetch('/getdata', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                    },
                    body: JSON.stringify({ message }),
                });
                
                const data = await response.json();
                console.log(data.reply);
                simulateTyping(data.reply); 
                appendMessage(data.response, 'assistant');
            } catch (error) {
                console.error('Error:', error);
                appendMessage('Error: Unable to fetch response.', 'assistant');
            }finally {
        // Hide the loading spinner after the response is received or after an error
        loading.style.display = 'none'; // Hide the loader
    }
        });

        userMessageInput.addEventListener('keydown', (event) => {
            if (event.key === 'Enter') sendButton.click();
        });

        function simulateTyping(reply) {
            var replyBox = $('<div class="message ai">').html("<i>Typing...</i>");
            $('#chat-box').append(replyBox);
            scrollToBottom();

            var typingText = "";
            var typingSpeed = 100; // Adjust the typing speed (ms per character)
            var i = 0;

            // Simulate typing by adding one character at a time
            var interval = setInterval(function() {
                typingText += reply.charAt(i);
                replyBox.html(typingText);
                i++;

                if (i > reply.length) {
                    clearInterval(interval); // Stop typing once the message is complete
                }
            }, typingSpeed);
        }

        // Scroll to the bottom of the chat container to show the latest message
        function scrollToBottom() {
            $('#chat-container').scrollTop($('#chat-container')[0].scrollHeight);
        }
    </script>
</body>
</html>
<?php /**PATH C:\wamp64\www\Laravel\bluemeins--workn\resources\views/chatnew.blade.php ENDPATH**/ ?>