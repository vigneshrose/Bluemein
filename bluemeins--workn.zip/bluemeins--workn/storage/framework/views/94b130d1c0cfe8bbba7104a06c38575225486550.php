<div id="chat-box">
    <div id="messages">
        <!-- Messages will be appended here -->
    </div>

    <textarea id="message-input" placeholder="Type a message"></textarea>
    <button id="send-btn">Send</button>
</div>

<script>
    document.getElementById('send-btn').addEventListener('click', async () => {
        const message = document.getElementById('message-input').value;
        if (message.trim() !== '') {
            const response = await fetch('/chat', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                },
                body: JSON.stringify({ message }),
            });

            const data = await response.json();
            // Append the response to the chat box
            const messagesContainer = document.getElementById('messages');
            messagesContainer.innerHTML += `<p><strong>User:</strong> ${message}</p>`;
            messagesContainer.innerHTML += `<p><strong>ChatGPT:</strong> ${data.reply}</p>`;
            document.getElementById('message-input').value = '';
        }
    });
</script>
<?php /**PATH C:\wamp64\www\Laravel\bluemein\resources\views/chat.blade.php ENDPATH**/ ?>